package com.example.trackery;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class view_products extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_products);
    }
}