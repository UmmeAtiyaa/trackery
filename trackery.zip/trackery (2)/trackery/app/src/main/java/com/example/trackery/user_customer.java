package com.example.trackery;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import androidx.appcompat.app.AppCompatActivity;

public class user_customer extends AppCompatActivity {
    CustomerDBHelper custDB;
    public ListView lv;
    SimpleCursorAdapter simpleCursorAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_customer);
        ImageButton search = (ImageButton) findViewById(R.id.searchButton);
        EditText searchView = (EditText) findViewById(R.id.searchbox);
        lv = findViewById(R.id.custlv);
        custDB = new CustomerDBHelper(this);
        try{
            setcustadapter();
        }catch (NullPointerException ex){
            ex.printStackTrace();
        }

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Cursor cursor = (Cursor) simpleCursorAdapter.getItem(position);
                String c_id = cursor.getString(0);
                String str_id = String.valueOf(c_id);
                Intent intent = new Intent(getApplicationContext(), user_customerdetails.class);
                intent.putExtra("CID", str_id);
                startActivity(intent);
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchView.setVisibility(View.VISIBLE);

                searchView.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                        simpleCursorAdapter = custDB.searching(charSequence);
                        lv.setAdapter(simpleCursorAdapter);
                    }

                    @Override
                    public void afterTextChanged(Editable editable) {
                    }
                });

            }

        });
    }
    public void setcustadapter() {
        simpleCursorAdapter=custDB.getcustomerdata();
        lv.setAdapter(simpleCursorAdapter);
    }

    @Override
    public void onResume(){
        super.onResume();
        simpleCursorAdapter=custDB.getcustomerdata();
        lv.setAdapter(simpleCursorAdapter);

    }
}

