package com.example.trackery;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class user_customerdetails extends AppCompatActivity {
    private EditText id,name,mobile,email;
    CustomerDBHelper CDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_customerdetails);

        id=(EditText) findViewById(R.id.upCID);
        name=(EditText) findViewById(R.id.upCN);
        mobile=(EditText) findViewById(R.id.upCPH);
        email=(EditText) findViewById(R.id.upCE);
        CDB= new CustomerDBHelper(this);

        Intent i= getIntent();
        String string_id= i.getStringExtra("CID");
        Cursor res= CDB.SingleCustomer(string_id);
        if (res.getCount()>0){
            res.moveToFirst();
            id.setText(res.getString(0));
            name.setText(res.getString(1));
            mobile.setText(res.getString(2));
            email.setText(res.getString(3));
        }
        id.setFocusableInTouchMode(false);
        name.setFocusableInTouchMode(false);
        mobile.setFocusableInTouchMode(false);
        email.setFocusableInTouchMode(false);
    }
}