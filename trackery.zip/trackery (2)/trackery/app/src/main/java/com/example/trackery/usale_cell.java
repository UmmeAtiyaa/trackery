package com.example.trackery;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class usale_cell extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usale_cell);
    }
}